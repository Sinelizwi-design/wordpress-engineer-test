<?php
/**
   *@package SinelizwiPlugin
   */
   /**
   plugin Name: Events Post and Metabox
   Plugin URI: http://sinelizwi.com/plugin
   Description: This is the plugin for creating custom post types, metabox and exposing to Wordpress API
   version: 1.0.0
   Author: Sinelizwi Gebeda
   Author URI: http://sinelizwi.com
   License: GPLv2 or later
   Text Domain: events
   */   

   //security
if(! defined ('ABSPATH')){
	die;
}

//Check if the function name exists
if(! function_exists('sinelizwi_event_post_type')){
	

//Create a function for custom post type
function sinelizwi_event_post_type() {
 
    // Event custom type post
    $labels = array( 
 
        'name' => __( 'Events' , 'events' ),
 
        'singular_name' => __( 'Events' , 'events' ),
 
        'add_new' => __( 'New Event' , 'events' ),
 
        'add_new_item' => __( 'Add New Event' , 'events' ),
 
        'edit_item' => __( 'Edit Event' , 'events' ),
 
        'new_item' => __( 'New Event' , 'events' ),
 
        'view_item' => __( 'View Event' , 'events' ),
 
        'search_items' => __( 'Search Event' , 'events' ),
 
        'not_found' =>  __( 'No Event Found' , 'events' ),
 
        'not_found_in_trash' => __( 'No Movies found in Trash' , 'events' ),
 
    );
 
    $args = array(
 
        'labels' => $labels,
 
        'has_archive' => true,
		'capability_type' => 'post',
 
        'public' => true,
 
        'hierarchical' => false,

        'supports' => array(
            'title', 
            'editor', 
            'thumbnail',
        ),
 
        'rewrite'   => array( 'slug' => 'events' ),
        'show_in_rest' => true,
		
		
		/*
        'rest_base'   => 'events',
        'rest_controller_class'  => 'WP_REST_Posts_Controller',
        'supports'				=> array ('title', 'editor', 'thumbnail')*/
    );
	
 	  register_post_type( 'sinelizwi_events', $args);

}
}

else{
	
	//If the function name exists, exit
	die;
}
add_action( 'init', 'sinelizwi_event_post_type' );


//Check if the function name exists
if (! function_exists('events_metabox'))
{

//Creating a metabox 
 function events_metabox(){
	 
	 add_meta_box(
	 'events-id',          //id of metabox
	 'Events details',    //title of metabox
	 'events_template',  //custom fields function
	 'sinelizwi_events',   //custom post type
	 'normal',
	 'low'
	 );
 }
	 
 }else{
	 
	 //If the function name exists, exit
	 die;
}

//Check if the function name exists
if(! function_exists('events_template')){
	
	//Create a new function for html fields
 function events_template(){
	 ?>
	 <!--
	 HTML fields for meta box 
	 -->
	 <label for="date">  Enter Date </label><br>
	   <input type="date" id="date" name="date" ><br><br>
 <label for="price">  Enter ticket price </label><br>
	   <input type="text" id="price" name="price" placeholder="R1000"><br><br>
 <label for="available">Tickets available </label><br>
	   <input type="number" id="available" name="available" >

	 <?php
 }
}else{
	
	//If the function name exists, exit 
	die;
}
  add_action('add_meta_boxes','events_metabox');
  

//expose the custom post types to the REST API

add_action( 'rest_api_init', 'create_api_posts_meta_field' );
 
function create_api_posts_meta_field() {
 
 // register_rest_field ( 'name-of-post-type', 'name-of-field-to-return', array-of-callbacks-and-schema() )
 register_rest_field( 'sinelizwi_events', 'events_metabox', array(
 'get_callback' => 'get_post_meta_for_api',
 'schema' => null,
 )
 );
}
 
function get_post_meta_for_api( $object ) {
 //get the id of the post object array
 $post_id = $object['id'];
 
 //return the post meta
 return get_post_meta( $post_id );
}


?>